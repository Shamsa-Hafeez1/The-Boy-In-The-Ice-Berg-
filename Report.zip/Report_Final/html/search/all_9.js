var searchData=
[
  ['makeenemy_25',['makeEnemy',['../class_game.html#a6f7ef1551e8d5793e528ee6cf8ae8507',1,'Game']]],
  ['move_26',['move',['../class_fire_nation_guards.html#a3503c6062d9f26808f150726cd2d9949',1,'FireNationGuards']]]
];
