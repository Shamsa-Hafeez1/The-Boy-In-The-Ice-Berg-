var searchData=
[
  ['updateenemy_96',['updateEnemy',['../class_game.html#a47211386ef95be19caffb76d79866ec0',1,'Game']]],
  ['updatescoring_97',['updateScoring',['../class_game.html#ac775a880dfbabb522a4bc1cc3c4f0d38',1,'Game::updateScoring(Aang &amp;player)'],['../class_game.html#a4dc0d77f54ac91593ebc6f549e933af9',1,'Game::updateScoring(Aang &amp;player, PrinceZuko &amp;zuko)']]]
];
