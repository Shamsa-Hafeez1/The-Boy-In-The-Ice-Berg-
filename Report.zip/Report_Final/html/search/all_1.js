var searchData=
[
  ['close_6',['close',['../class_game.html#ad5133caa8447aadf71d6ba6c20d552bd',1,'Game']]]
];
