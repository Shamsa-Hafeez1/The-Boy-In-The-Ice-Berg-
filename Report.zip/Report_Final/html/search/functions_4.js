var searchData=
[
  ['fire_73',['Fire',['../class_fire.html#a646ac304c5779a9387ceefc06ea4f396',1,'Fire']]],
  ['firebending_74',['Firebending',['../class_firebending.html#ab6accffe97be6c10856dec24e9e51c8e',1,'Firebending']]],
  ['firecollidesplayer_75',['FireCollidesPlayer',['../class_game.html#a842d2c70e96642bfbfc36f0a3bed76ec',1,'Game']]]
];
