var searchData=
[
  ['init_77',['init',['../class_game.html#a8ff3a6838bad4ea9493c103f96d7bff3',1,'Game']]],
  ['isalive_78',['isAlive',['../class_aang.html#a79e84ea422e01baa34b28a0938791f99',1,'Aang::isAlive()'],['../class_fire_nation_guards.html#a9858fa49c27489ac2960b3c747f9f216',1,'FireNationGuards::isAlive()'],['../class_prince_zuko.html#ae33dee2dde120686bc256a7fab3088cf',1,'PrinceZuko::isAlive()']]],
  ['isfinished_79',['isFinished',['../class_health.html#a85aab7798a1ab9e8be9c1854f4fcdfce',1,'Health']]]
];
