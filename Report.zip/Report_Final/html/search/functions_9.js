var searchData=
[
  ['operator_2d_2d_84',['operator--',['../class_health.html#aa17cac54d3e65681434845299c817ec3',1,'Health']]],
  ['over_85',['Over',['../class_game.html#a1d5c07d7dbb22132c768e90035602de8',1,'Game']]]
];
